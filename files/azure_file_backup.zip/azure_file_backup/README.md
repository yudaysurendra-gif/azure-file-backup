# Azure File Backup

Back up a local folder to Azure Blob Storage. Only new or changed files are uploaded.

## Azure setup
1. In the Azure Portal, create a **Storage account**.
2. Open it > **Security + networking > Access keys** and copy a **Connection string**.
3. Copy `.env.example` to `.env` and paste the connection string.

## Install
    pip install -r requirements.txt

## Usage
    python azure_file_backup.py backup  ./my_documents
    python azure_file_backup.py backup  ./my_documents --name project1
    python azure_file_backup.py list
    python azure_file_backup.py list    --name project1
    python azure_file_backup.py restore project1 ./restored_files
    python azure_file_backup.py delete  project1

## How it works
- Each backup is stored in the container under `<backup name>/<relative file path>`.
- An MD5 hash is saved as blob metadata; unchanged files are skipped next time.
- Keep `.env` private and never commit it to GitHub.
